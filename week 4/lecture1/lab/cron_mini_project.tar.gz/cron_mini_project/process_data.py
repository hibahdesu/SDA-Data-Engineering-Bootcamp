#!/usr/bin python3

# Note that the instructions below are only for guidance.
# If you think of another method then please feel free to do however works for you.
# Be sure to read the Riyadh_weather.md for additional guidance.  Especially regarding character encoding.

# import packages


# File and directory paths


# Create the output directory if it doesn't exist

# Load new data


# Output path for the combined data


# Check if the output file already exists


# Append new data to the existing data list


# Save the updated data to a JSON file
